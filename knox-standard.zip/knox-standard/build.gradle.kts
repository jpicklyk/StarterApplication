import com.android.build.api.dsl.Packaging
import java.io.FileInputStream
import java.util.Properties

plugins {
    alias(libs.plugins.convention.android.feature)
    alias(libs.plugins.convention.android.knox.license)
}

android {
    namespace = "com.example.starterapplication.knox_standard"
    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        // ... other default config ...
        testInstrumentationRunner = "com.example.starterapplication.knox_standard.CustomTestRunner"
    }

    testOptions {
        execution = "ANDROIDX_TEST_ORCHESTRATOR"
    }

    packaging {
        resources {
            excludes += listOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*"
            )
        }
    }
}

dependencies {
    implementation(projects.core.common)
    implementation(projects.core.knox)
    implementation(libs.core.ktx)
    implementation(libs.androidx.core.ktx)

    testImplementation(libs.junit)
    testImplementation(libs.mockk)
    testImplementation(libs.androidx.runtime.android)
    testCompileOnly(fileTree("libs/knoxsdk.jar"))

    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(libs.hilt.android.testing)
    androidTestImplementation(libs.mockk.android)
    androidTestImplementation(libs.androidx.test.uiautomator)
    androidTestCompileOnly(fileTree("libs/knoxsdk.jar"))

    androidTestUtil(libs.androidx.test.orchestrator)
    androidTestUtil(libs.androidx.test.services)

    // The Knox SDK shall not be available outside this module
    compileOnly(fileTree("libs/knoxsdk.jar"))
}


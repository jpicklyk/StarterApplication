package com.example.starterapplication.knox_standard


import android.app.Application
import dagger.hilt.android.testing.CustomTestApplication

@CustomTestApplication(Application::class)
interface KnoxTestApplication
package com.example.starterapplication.knox_standard.feature

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.starterapplication.core.knox.api.ApiResult
import com.example.starterapplication.core.knox.feature.domain.KnoxFeatureManager
import com.example.starterapplication.core.knox.feature.domain.handler.KnoxFeatureHandler
import com.example.starterapplication.core.knox.feature.domain.handler.KnoxFeatureHandlerFactory
import com.example.starterapplication.core.knox.feature.domain.registry.KnoxFeatureRegistry
import com.example.starterapplication.knox_standard.policy.KnoxPolicyFeatureKey
import com.example.starterapplication.knox_standard.policy.usb.di.UsbPolicyModule
import com.example.starterapplication.knox_standard.policy.usb.domain.handler.UsbHostStorageHandler
import com.example.starterapplication.knox_standard.policy.usb.domain.usecase.AllowUsbHostStorageUseCase
import com.example.starterapplication.knox_standard.policy.usb.domain.usecase.IsUsbHostStorageAllowedUseCase
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import javax.inject.Inject

@HiltAndroidTest
@RunWith(AndroidJUnit4::class)
class KnoxFeatureIntegrationTest {

    @get:Rule
    var hiltRule = HiltAndroidRule(this)

    @Inject
    lateinit var knoxFeatureManager: KnoxFeatureManager

    @Inject
    lateinit var knoxFeatureHandlerFactory: KnoxFeatureHandlerFactory

    @Inject
    lateinit var knoxFeatureRegistry: KnoxFeatureRegistry

    //@Inject
    //lateinit var usbPolicyModule: UsbPolicyModule
    @Inject
    lateinit var usbHostStorageHandler: KnoxFeatureHandler<Boolean>

    @Inject
    lateinit var allowUsbHostStorageUseCase: AllowUsbHostStorageUseCase

    @Inject
    lateinit var isUsbHostStorageAllowedUseCase: IsUsbHostStorageAllowedUseCase

    @Before
    fun init() {
        hiltRule.inject()
    }

//    @Test
//    fun testUsbPolicyModuleIsProvided() {
//        assertNotNull("UsbPolicyModule should be provided", usbPolicyModule)
//    }

    @Test
    fun testKnoxFeatureHandlerFactoryIsProvided() {
        assertNotNull("KnoxFeatureHandlerFactory should be provided", knoxFeatureHandlerFactory)
    }

    @Test
    fun testKnoxFeatureRegistryIsProvided() {
        assertNotNull("KnoxFeatureRegistry should be provided", knoxFeatureRegistry)
    }

    @Test
    fun testKnoxFeatureManagerIsProvided() {
        assertNotNull("KnoxFeatureManager should be provided", knoxFeatureManager)
    }
    @Test
    fun testUsbHostStorageHandlerIsProvided() {
        val handler = knoxFeatureHandlerFactory.getHandler(KnoxPolicyFeatureKey.UsbHostStorage)
        assertNotNull("UsbHostStorageHandler should be provided", usbHostStorageHandler)
    }

    @Test
    fun testUsbHostStorageHandlerIsProvidedFromFactory() {
        val handler = knoxFeatureHandlerFactory.getHandler(KnoxPolicyFeatureKey.UsbHostStorage)
        assertNotNull("UsbHostStorageHandler should be provided", handler)
    }

    @Test
    fun testIsUsbHostStorageAllowedUseCaseIsProvided() {
        assertNotNull("IsUsbHostStorageAllowedUseCase should be provided", isUsbHostStorageAllowedUseCase)
    }

    @Test
    fun testAllowUsbHostStorageUseCaseIsProvided() {
        assertNotNull("AllowUsbHostStorageUseCase should be provided", allowUsbHostStorageUseCase)
    }

    @Test
    fun testUsbHostStorageFeatureIsRegistered() {
        val features = knoxFeatureRegistry.getFeatures()
        assertTrue("USB_HOST_STORAGE feature should be registered",
            features.any { it == KnoxPolicyFeatureKey.UsbHostStorage })
    }

    @Test
    fun testGetAllFeatures() = runBlocking {
        val result = knoxFeatureManager.getAllFeatures()
        assertTrue(result is ApiResult.Success)
        val features = (result as ApiResult.Success).data
        assertEquals(1, features.size)
        assertEquals("USB_HOST_STORAGE", features[0].key.featureName)
    }


}
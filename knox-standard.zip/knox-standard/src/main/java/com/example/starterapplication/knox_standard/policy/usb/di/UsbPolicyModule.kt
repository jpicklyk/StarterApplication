package com.example.starterapplication.knox_standard.policy.usb.di

import android.content.Context
import android.util.Log
import com.example.starterapplication.core.knox.feature.domain.registry.KnoxFeatureCategory
import com.example.starterapplication.core.knox.feature.domain.registry.KnoxFeatureRegistry
import com.example.starterapplication.core.knox.feature.domain.handler.KnoxFeatureHandlerKey
import com.example.starterapplication.core.knox.feature.domain.handler.KnoxFeatureHandler
import com.example.starterapplication.knox_standard.policy.KnoxPolicyFeatureKey
import com.example.starterapplication.knox_standard.policy.usb.domain.handler.UsbHostStorageHandler
import com.example.starterapplication.knox_standard.policy.usb.domain.usecase.AllowUsbHostStorageUseCase
import com.example.starterapplication.knox_standard.policy.usb.domain.usecase.IsUsbHostStorageAllowedUseCase
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.ClassKey
import dagger.multibindings.IntoMap
import javax.inject.Inject
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class UsbPolicyModule {
    private val tag = "UsbPolicyModule"

    init {
        Log.d(tag, "UsbPolicyModule initialized")
    }


    @Binds
    @Singleton
    abstract fun provideUsbHostStorageHandler(
        handler: UsbHostStorageHandler
    ) : KnoxFeatureHandler<Boolean>

//    @Binds
//    @Singleton
//    @IntoMap
//    @ClassKey(KnoxPolicyFeatureKey.UsbHostStorage::class)
//    fun provideUsbHostStorageHandlerIntoMap(
//        handler: UsbHostStorageHandler,
//        featureRegistry: KnoxFeatureRegistry
//    ): KnoxFeatureHandler<Boolean> {
//        Log.d(tag, "Providing UsbHostStorageHandler")
//        featureRegistry.registerFeature(KnoxPolicyFeatureKey.UsbHostStorage, KnoxFeatureCategory.PRODUCTION)
//        Log.d(tag, "Registered USB_HOST_STORAGE feature")
//        return handler
//    }
}
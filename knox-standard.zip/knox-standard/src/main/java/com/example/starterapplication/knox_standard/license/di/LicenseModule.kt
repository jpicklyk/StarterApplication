package com.example.starterapplication.knox_standard.license.di

import android.content.Context
import com.example.starterapplication.knox_standard.license.data.KnoxErrorMapper
import com.example.starterapplication.knox_standard.license.domain.repository.LicenseRepository
import com.example.starterapplication.knox_standard.license.domain.usecase.GetLicenseInfoUseCase
import com.example.starterapplication.knox_standard.license.domain.usecase.KnoxLicenseUseCase
import com.example.starterapplication.knox_standard.license.data.LicenseRepositoryImpl
import com.example.starterapplication.knox_standard.license.domain.usecase.GetLicenseInfoUseCaseImpl
import com.example.starterapplication.knox_standard.license.domain.usecase.KnoxLicenseUseCaseImpl
import com.example.starterapplication.core.common.presentation.ResourceProvider
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object LicenseModule {

    @Provides
    @Singleton
    fun provideLicenseRepository(
        knoxLicenseUseCase: KnoxLicenseUseCase,
        getLicenseInfoUseCase: GetLicenseInfoUseCase
    ): LicenseRepository {
        return LicenseRepositoryImpl(
            knoxLicenseUseCase,
            getLicenseInfoUseCase
        )
    }


    @Provides
    @Singleton
    internal fun provideKnoxLicenseUseCase(
        @ApplicationContext context: Context,
        knoxErrorMapper: KnoxErrorMapper
    ): KnoxLicenseUseCase {
        return KnoxLicenseUseCaseImpl(context, knoxErrorMapper)
    }

    @Provides
    @Singleton
    internal fun provideGetLicenseInfoUseCase(
        @ApplicationContext context: Context
        ): GetLicenseInfoUseCase {
        return GetLicenseInfoUseCaseImpl(context)
    }

    @Provides
    @Singleton
    fun provideKnoxErrorMapper(resourceProvider: ResourceProvider): KnoxErrorMapper {
        return KnoxErrorMapper(resourceProvider)
    }
}
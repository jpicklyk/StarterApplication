package com.example.starterapplication.knox_standard.policy.usb.domain.handler

import com.example.starterapplication.core.knox.api.ApiResult
import com.example.starterapplication.core.knox.feature.domain.handler.KnoxFeatureHandler
import com.example.starterapplication.core.knox.feature.presentation.KnoxFeatureState
import com.example.starterapplication.core.knox.feature.presentation.wrapInFeatureState
import com.example.starterapplication.knox_standard.policy.usb.domain.usecase.AllowUsbHostStorageUseCase
import com.example.starterapplication.knox_standard.policy.usb.domain.usecase.IsUsbHostStorageAllowedUseCase
import javax.inject.Inject

class UsbHostStorageHandler @Inject constructor(
    private val getUseCase: IsUsbHostStorageAllowedUseCase,
    private val setUseCase: AllowUsbHostStorageUseCase
) : KnoxFeatureHandler<Boolean> {
    override suspend fun getState(): ApiResult<KnoxFeatureState<Boolean>> = getUseCase().wrapInFeatureState()
    override suspend fun setState(newState: KnoxFeatureState<Boolean>): ApiResult<Unit> = setUseCase(newState.value)
}